# How to Use **Spiral Dungeon of Babel**  

Welcome to **Spiral Dungeon of Babel**! Follow this guide to install and start using the mod.  

## Requirements  
- **Minecraft Forge** version **1.20.1**  
  Make sure you have Forge installed, as it is required to run the mod. You can download it from [Forge](https://files.minecraftforge.net/).  

## Installation  
1. **Download the mod**:  
   - You can get **Spiral Dungeon of Babel** from:  
     - [CurseForge](https://www.curseforge.com/minecraft/mc-mods/sdob)  
     - [Modrinth](https://modrinth.com/mod/sdob)  
     - [GameJolt](https://gamejolt.com/games/sdob/953274)  
     - [Itch.io](https://d4vide106.itch.io/sdob-mc) 

2. **Install the mod**:  
   - Move the downloaded `.jar` file into the `mods` folder in your Minecraft directory.  
     - **Windows**: `C:\Users\[Your Username]\AppData\Roaming\.minecraft\mods`  
     - **Mac**: `~/Library/Application Support/minecraft/mods`  
     - **Linux**: `~/.minecraft/mods`  

3. **Launch Minecraft**:  
   - Select the Forge 1.20.1 profile in the launcher and start the game.  

## How to Play  
- **Naturally Generated Structures**: Once the mod is installed, explore your world to find new structure.
- **Compatibility**: The mod works with existing worlds, but for the best experience, we recommend starting a new world.  

## Support and Assistance  
Need help? Want to report a bug or suggest new ideas?  
Join our **Discord** server: [Click here](https://discord.gg/thfPJ7QAPJ).  

Enjoy your adventure and have fun with **Spiral Dungeon of Babel**!  
